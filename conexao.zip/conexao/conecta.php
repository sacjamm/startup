<?php
session_start();
date_default_timezone_set("America/Sao_Paulo");
@ini_set('magic_quotes_runtime', 0);
@ini_set('magic_quotes_sybase', 0);
@ini_set('output_handler', 'mb_output_handler');
@ini_get('upload_max_filesize');
ini_set("memory_limit", "128M");
//echo phpinfo();
php_ini_loaded_file();

$_SESSION['visitante'] = $_SERVER['REMOTE_ADDR'];
//echo $_SESSION['visitante'];
//echo $_SERVER['REQUEST_URI'];//filter_input(INPUT_SERVER, 'REQUEST_URI', FILTER_DEFAULT);
function __autoload($Class) {


    $cDir = ['Classes', 'Helpers', 'Models'];
    $iDir = null;

    foreach ($cDir as $dirName):
        if (!$iDir && file_exists(__DIR__ . DIRECTORY_SEPARATOR . $dirName . DIRECTORY_SEPARATOR . $Class . '.class.php') && !is_dir(__DIR__ . DIRECTORY_SEPARATOR . $dirName . DIRECTORY_SEPARATOR . $Class . '.class.php')):
            include_once (__DIR__ . DIRECTORY_SEPARATOR . $dirName . DIRECTORY_SEPARATOR . $Class . '.class.php');
            $iDir = true;
        endif;
    endforeach;

    if (!$iDir):

        trigger_error("Não foi poss�vel incluir {$Class}.class.php", E_USER_ERROR);

        die;
    endif;
}

$funcoes = new Funcoes;


define('HOST', "mysql.rohr.ind.br");
define('USER', "rohr");
define('PASS', "a4t3d8");
define('BANCO', "rohr");
define('PREFIX', "ws_");

// DEFINE A BASE DO SITE ####################
define('BASE', 'http://www.rohr.ind.br');
define('ADMIN', BASE . '/admin');
define('BASEPATH', 'admin');
define('HOME', BASE);
define('THEME', 'rohr');



define('INCLUDE_PATH', BASE . DIRECTORY_SEPARATOR . 'themes' . DIRECTORY_SEPARATOR . THEME);
define('REQUIRE_PATH', 'themes' . DIRECTORY_SEPARATOR . THEME);

define('WS_ACCEPT', 'success');
define('WS_INFOR', 'info');
define('WS_ALERT', 'warning');
define('WS_ERROR', 'danger');

// DEFINE SERVIDOR DE E-MAIL ################
//define('MAILHOST', "ssl://smtp.gmail.com");
//define('MAILPORT', "465");
//define('MAILUSER', "sac.jamm@gmail.com");
//define('MAILPASS', "!nameiswhat1504#");
// DEFINE SERVIDOR DE E-MAIL ################

$Config = new Read();
$Config->ExeRead(PREFIX . "config");
$etConfig = $Config->getResult()[0];

define('MAILHOST', "{$etConfig->config_hostname}");
define('MAILPORT', "{$etConfig->config_port}");
define('MAILUSER', "{$etConfig->config_user}");
define('MAILPASS', "{$etConfig->config_password}");

// DEFINE IDENTIDADE DO SITE ################
define('SITENAME', "{$etConfig->config_title}");
define('SITEDESC', "{$etConfig->config_description}");
define('KEYWORDS', "{$etConfig->config_keywords}");


include_once $_SERVER['DOCUMENT_ROOT'] . BASEPATH . '/conexao/Helpers/class.smtp.php';
include_once $_SERVER['DOCUMENT_ROOT'] . BASEPATH . '/conexao/Helpers/class.phpmailer.php';

//WSErro :: Exibe erros lanÃ§ados :: Front
function WLMsg($ErrMsg, $ErrNo, $ErrDie = null) {
    $CssClass = ($ErrNo == E_USER_NOTICE ? WS_INFOR : ($ErrNo == E_USER_WARNING ? WS_ALERT : ($ErrNo == E_USER_ERROR ? WS_ERROR : $ErrNo)));
    echo "<div class=\"alert alert-{$CssClass}\">"
    . "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>";
    echo "{$ErrMsg}";
    echo "</div>";

    if ($ErrDie):
        die;
    endif;
}

$Site = new Site;
$margin = 'style="margin:5px 0;"';

//PHPErro :: personaliza o gatilho do PHP
function PHPErro($ErrNo, $ErrMsg, $ErrFile, $ErrLine) {
    $CssClass = ($ErrNo == E_USER_NOTICE ? WS_INFOR : ($ErrNo == E_USER_WARNING ? WS_ALERT : ($ErrNo == E_USER_ERROR ? WS_ERROR : $ErrNo)));
    echo "<div class=\"alert alert-{$CssClass}danger\">"
    . "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>";
    echo "Erro na Linha: #{$ErrLine} ::</b> {$ErrMsg}<br>";
    echo "<small>{$ErrFile}</small>";
    echo "</div>";

    if ($ErrNo == E_USER_ERROR):
        die;
    endif;
}

set_error_handler('PHPErro');

try {
    $conexao = new PDO("mysql:host=" . HOST . ";dbname=" . BANCO, USER, PASS);
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "<div class=\"alert alert-danger\">"
    . "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>";
    echo "Erro na Linha: #{$e->getLine()} ::</b> {$e->getMessage()}<br>";
    echo "<small>{$e->getFile()}</small>";
    echo "</div>";
}

if (isset($_POST['config_cep'])):
    $cep = $_POST['config_cep'];
///$url = "http://xtends.com.br/webservices/cep/json/$cep/";
    $url = "http://clareslab.com.br/ws/cep/json/$cep/";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    echo curl_exec($ch);
    curl_close($ch); 
endif;