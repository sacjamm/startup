<?php

/**
 * Seo [ MODEL ]
 * Classe de apoio para o modelo LINK. Pode ser utilizada para gerar SSEO para as páginas do sistema!
 * 
 * @copyright (c) 2015, Alisson Maciel AGÊNCIA DIGITAL WEB LAB
 */
class Seo {

    private $File;
    private $Link;
    private $Data;
    private $Tags;

    /* DADOS POVOADOS */
    private $seoTags;
    private $seoData;

    function __construct($File, $Link) {
        $this->File = strip_tags(trim($File));
        $this->Link = strip_tags(trim($Link));
    }

    /**
     * <b>Obter MetaTags:</b> Execute este método informando os valores de navegação para que o mesmo obtenha
     * todas as metas como title, description, og, itemgroup, etc.
     * 
     * <b>Deve ser usada com um ECHO dentro da tag HEAD!</b>
     * @return HTML TAGS =  Retorna todas as tags HEAD
     */
    public function getTags() {
        $this->checkData();
        return $this->seoTags;
    }

    /**
     * <b>Obter Dados:</b> Este será automaticamente povoado com valores de uma tabela single para arquivos
     * como categoria, artigo, etc. Basta usar um extract para obter as variáveis da tabela!
     * 
     * @return ARRAY = Dados da tabela
     */
    public function getData() {
        $this->checkData();
        return $this->seoData;
    }

    /*
     * ***************************************
     * **********  PRIVATE METHODS  **********
     * ***************************************
     */

    //Verifica o resultset povoando os atributos
    private function checkData() {
        if (!$this->seoData):
            $this->getSeo();
        endif;
    }

    //Identifica o arquivo e monta o SEO de acordo
    private function getSeo() {
        $ReadSeo = new Read;
        $ReadEstado = new Read;

        switch ($this->File):
            //SEO:: POST
            case 'noticias':
                $Admin = (isset($_SESSION['userlogin']->user_level) && $_SESSION['userlogin']->user_level == 3 ? true : false);
                $Check = ($Admin ? '' : 'post_status = 1 AND');
                $type = 'post';
                $ReadSeo->ExeRead("ws_posts", "WHERE {$Check} post_name = :link AND post_type = :type", "link={$this->Link}&type={$type}");
                if (!$ReadSeo->getResult()):
                    $this->seoData = null;
                    $this->seoTags = null;
                    $this->Data = ['Notícias - ' . SITENAME, 'Notícias sobre a Proceramica', BASE . "/artigo/", BASE . "/images/noimage.gif.jpg", KEYWORDS];
                else:
                    $extract = $ReadSeo->getResult()[0];
                    $this->seoData = $ReadSeo->getResult()[0];
                    $this->Data = [$extract->post_title . ' - ' . SITENAME, $extract->post_content, BASE . "/artigo/{$extract->post_name}", BASE . "/uploads/{$extract->post_cover}", KEYWORDS];

                    //post:: conta views do post
                    $ArrUpdate = ['post_views' => $extract->post_views + 1];
                    $Update = new Update();
                    $Update->ExeUpdate("ws_posts", $ArrUpdate, "WHERE post_id = :postid", "postid={$extract->post_id}");
                endif;

                break;

            case 'pages':
                $Admin = (isset($_SESSION['userlogin']->user_level) && $_SESSION['userlogin']->user_level == 3 ? true : false);
                $Check = ($Admin ? '' : 'post_status = 1 AND');
                $type = 'page';
                $ReadSeo->ExeRead("ws_posts", "WHERE {$Check} post_name = :link AND post_type = :type", "link={$this->Link}&type={$type}");
                if (!$ReadSeo->getResult()):
                    $this->seoData = null;
                    $this->seoTags = null;
                    $this->Data = ['Pagínas - ' . SITENAME, 'Páginas da ' . SITENAME, BASE . "/pages/", BASE . "/images/noimage.gif.jpg", KEYWORDS];
                else:
                    $extract = $ReadSeo->getResult()[0];
                    $this->seoData = $ReadSeo->getResult()[0];
                    $this->Data = [$extract->post_title . ' - ' . SITENAME, $extract->post_content, BASE . "/pages/{$extract->post_name}", BASE . "/uploads/{$extract->post_cover}", KEYWORDS];

                    //post:: conta views do post
                    $ArrUpdate = ['post_views' => $extract->post_views + 1];
                    $Update = new Update();
                    $Update->ExeUpdate("ws_posts", $ArrUpdate, "WHERE post_id = :postid", "postid={$extract->post_id}");
                endif;
                break;

            case 'representantes':
                $Admin = (isset($_SESSION['userlogin']->user_level) && $_SESSION['userlogin']->user_level == 3 ? true : false);
                $Check = ($Admin ? '' : 'representante_status = 1 AND');
                $type = 'page';

                $ReadEstado->ExeRead("app_estados", "WHERE estado_uf = :link", "link={$this->Link}");
                if (!$ReadEstado->getRowCount()):
                    echo "Sem representantes cadastrados";
                else:
                    if (!$ReadEstado->getResult()):
                        echo "Sem representantes cadastrados";
                    else:
                        $estado = $ReadEstado->getResult()[0];

                        $ReadSeo->ExeRead("ws_representantes", "WHERE {$Check} representante_estado = :e", "e={$estado->estado_id}");
                        if (!$ReadSeo->getResult()):
                            $this->seoData = null;
                            $this->seoTags = null;
                            $this->Data = ['Pagínas - ' . SITENAME, 'Páginas da ' . SITENAME, BASE . "/representantes/", BASE . "/images/noimage.gif.jpg", KEYWORDS];
                        else:
                            $extract = $ReadSeo->getResult()[0];
                            $this->seoData = $ReadSeo->getResult()[0];
                            $this->Data = [$estado->estado_nome . ' - ' . SITENAME, $estado->estado_nome, BASE . "/representantes/", BASE . "/images/noimage.gif.jpg", KEYWORDS];

                        //post:: conta views do post
//                    $ArrUpdate = ['post_views' => $extract->post_views + 1];
//                    $Update = new Update();
//                    $Update->ExeUpdate("ws_posts", $ArrUpdate, "WHERE post_id = :postid", "postid={$extract->post_id}");
                        endif;
                    endif;
                endif;
                $this->Data = ['Pagínas - ' . SITENAME, 'Páginas da ' . SITENAME, BASE . "/representantes/", BASE . "/images/noimage.gif.jpg", KEYWORDS];
                break;

            case 'servicos':
                $Admin = (isset($_SESSION['userlogin']->user_level) && $_SESSION['userlogin']->user_level == 3 ? true : false);
                $Check = ($Admin ? '' : 'post_status = 1 AND');
                $type = 'servico';
                $ReadSeo->ExeRead("ws_posts", "WHERE {$Check} post_name = :link AND post_type = :type", "link={$this->Link}&type={$type}");
                if (!$ReadSeo->getResult()):
                    $this->seoData = null;
                    $this->seoTags = null;
                    $this->Data = ['Serviços - ' . SITENAME, 'Serviços que a Proceramica oferece', BASE . "/servicos/", BASE . "/images/noimage.gif.jpg", KEYWORDS];
                else:
                    $extract = $ReadSeo->getResult()[0];
                    $this->seoData = $ReadSeo->getResult()[0];
                    $this->Data = [$extract->post_title . ' - ' . SITENAME, $extract->post_content, BASE . "/servicos/{$extract->post_name}", BASE . "/uploads/{$extract->post_cover}", KEYWORDS];

                    //post:: conta views do post
                    $ArrUpdate = ['post_views' => $extract->post_views + 1];
                    $Update = new Update();
                    $Update->ExeUpdate("ws_posts", $ArrUpdate, "WHERE post_id = :postid", "postid={$extract->post_id}");
                endif;

                break;

            case 'produtos':
                $Admin = (isset($_SESSION['userlogin']->user_level) && $_SESSION['userlogin']->user_level == 3 ? true : false);
                $Check = ($Admin ? '' : 'post_status = 1 AND');
                $type = 'produto';

                $ReadSeo->ExeRead("ws_posts", "WHERE {$Check} post_name = :link", "link={$this->Link}");
                if (!$ReadSeo->getResult()):
                    $this->seoData = null;
                    $this->seoTags = null;
                else:
                    $extract = extract($ReadSeo->getResult()[0]);
                    $this->seoData = $ReadSeo->getResult()[0];
                    $this->Data = [$post_title . ' - ' . SITENAME, $post_content, BASE . "/produto/{$post_name}", BASE . "/uploads/{$post_cover}", KEYWORDS];

                    //post:: conta views do post
                    $ArrUpdate = ['post_views' => $post_views + 1];
                    $Update = new Update();
                    $Update->ExeUpdate("ws_posts", $ArrUpdate, "WHERE post_id = :postid", "postid={$post_id}");
                endif;
                break;

            //SEO:: CATEGORIA
            case 'categoria':
                $ReadSeo->ExeRead("ws_categorias", "WHERE category_name = :link", "link={$this->Link}");
                if (!$ReadSeo->getResult()):
                    $this->seoData = null;
                    $this->seoTags = null;
                else:
                    extract($ReadSeo->getResult()[0]);
                    $this->seoData = $ReadSeo->getResult()[0];
                    $this->Data = [$category_title . ' - ' . SITENAME, $category_content, BASE . "/categoria/{$category_name}", INCLUDE_PATH . '/images/logo.png', KEYWORDS];

                    //category:: conta views da categoria
                    $ArrUpdate = ['category_views' => $category_views + 1];
                    $Update = new Update();
                    $Update->ExeUpdate("ws_categorias", $ArrUpdate, "WHERE category_id = :catid", "catid={$category_id}");
                endif;
                break;

            //SEO:: PESQUISA
            case 'pesquisa':
                $ReadSeo->ExeRead("ws_produtos", "WHERE statusProduto = 1 AND (tituloProduto LIKE '%' :link '%' OR descricaoProduto LIKE '%' :link '%')", "link={$this->Link}");
                if (!$ReadSeo->getResult()):
                    $this->seoData = null;
                    $this->seoTags = null;
                else:
                    $this->seoData['count'] = $ReadSeo->getRowCount();
                    $this->Data = ["Pesquisa por: {$this->Link}" . ' - ' . SITENAME, "Sua pesquisa por {$this->Link} retornou {$this->seoData['count']} resultados!", BASE . "/pesquisa/{$this->Link}", INCLUDE_PATH . '/images/logo.png', KEYWORDS];
                endif;
                break;

            //SEO:: LISTA EMPRESAS
            case 'empresas':
                $Name = ucwords(str_replace("-", " ", $this->Link));
                $this->seoData = ["empresa_link" => $this->Link, "empresa_cat" => $Name];
                $this->Data = ["Empresas {$this->Link}" . SITENAME, "Confira o guia completo de sua cidade, e encontra empresas {$this->Link}.", BASE . '/empresas/' . $this->Link, INCLUDE_PATH . '/images/logo.png', KEYWORDS];
                break;

            //SEO:: EMPRESA SINGLE
            case 'empresa':
                $Admin = (isset($_SESSION['userlogin']->user_level) && $_SESSION['userlogin']->user_level == 3 ? true : false);
                $Check = ($Admin ? '' : 'empresa_status = 1 AND');

                $ReadSeo->ExeRead("app_empresas", "WHERE {$Check} empresa_name = :link", "link={$this->Link}");
                if (!$ReadSeo->getResult()):
                    $this->seoData = null;
                    $this->seoTags = null;
                else:
                    extract($ReadSeo->getResult()[0]);
                    $this->seoData = $ReadSeo->getResult()[0];
                    $this->Data = [$empresa_title . ' - ' . SITENAME, $empresa_sobre, BASE . "/empresa/{$empresa_name}", BASE . "/uploads/{$empresa_capa}", KEYWORDS];

                    //empresa:: conta views da empresa
                    $ArrUpdate = ['empresa_views' => $empresa_views + 1];
                    $Update = new Update();
                    $Update->ExeUpdate("app_empresas", $ArrUpdate, "WHERE empresa_id = :empresaid", "empresaid={$empresa_id}");
                endif;
                break;


            //SEO:: INDEX
            case 'index':
                $this->Data = [SITENAME . ' - ' . SITEDESC, SITEDESC, BASE, INCLUDE_PATH . '/images/logo.png', KEYWORDS];
                break;
            case 'contato':
                $id = 1;
                $ReadSeo->ExeRead("ws_config", "WHERE config_id = :id", "id={$id}");
                if (!$ReadSeo->getResult()):
                    $this->seoData = null;
                    $this->seoTags = null;
                    $this->Data = ['Contato - ' . SITENAME . ' - ' . SITEDESC, SITEDESC, BASE, INCLUDE_PATH . '/images/logo.png', KEYWORDS];
                else:
                    $extract = $ReadSeo->getResult()[0];
                    $this->seoData = $ReadSeo->getResult()[0];
                    $this->Data = ['Contato - ' . SITENAME, SITEDESC, BASE . "/contato/", BASE . '/images/logo.png', KEYWORDS];
                endif;
                //$this->Data = ['Contato - ' . SITENAME . ' - ' . SITEDESC, SITEDESC, BASE, INCLUDE_PATH . '/images/logo.png', KEYWORDS];
                break;

            //SEO:: 404
            default :
                $this->Data = [SITENAME . ' - 404 Oppsss, Nada encontrado!', SITEDESC, BASE . '/404', INCLUDE_PATH . '/images/logo.png', KEYWORDS];

        endswitch;

        if ($this->Data):
            $this->setTags();
        endif;
    }

    //Monta e limpa as tags para alimentar as tags
    private function setTags() {
        $Check = new Check;
        $this->Tags['Title'] = $this->Data[0];
        $this->Tags['Content'] = $Check->Words(html_entity_decode($this->Data[1]), 25);
        $this->Tags['Link'] = $this->Data[2];
        $this->Tags['Image'] = $this->Data[3];
        $this->Tags['Keywords'] = $this->Data[4];

        $this->Tags = array_map('strip_tags', $this->Tags);
        $this->Tags = array_map('trim', $this->Tags);

        $this->Data = null;

        //NORMAL PAGE
        $this->seoTags = '<title>' . $this->Tags['Title'] . '</title> ' . "\n";
        $this->seoTags .= '<meta name="description" content="' . $this->Tags['Content'] . '"/>' . "\n";
        $this->seoTags .= '<meta name="keywords" content="' . $this->Tags['Keywords'] . '"/>' . "\n";
        $this->seoTags .= '<meta name="robots" content="index, follow" />' . "\n";
        $this->seoTags .= '<link rel="canonical" href="' . $this->Tags['Link'] . '">' . "\n";
        $this->seoTags .= "\n";

        //FACEBOOK
        $this->seoTags .= '<meta property="og:site_name" content="' . SITENAME . '" />' . "\n";
        $this->seoTags .= '<meta property="og:locale" content="pt_BR" />' . "\n";
        $this->seoTags .= '<meta property="og:title" content="' . $this->Tags['Title'] . '" />' . "\n";
        $this->seoTags .= '<meta property="og:description" content="' . $this->Tags['Content'] . '" />' . "\n";
        $this->seoTags .= '<meta property="og:image" content="' . $this->Tags['Image'] . '" />' . "\n";
        $this->seoTags .= '<meta property="og:url" content="' . $this->Tags['Link'] . '" />' . "\n";
        $this->seoTags .= '<meta property="og:type" content="article" />' . "\n";
        $this->seoTags .= "\n";

        //ITEM GROUP (TWITTER)
        $this->seoTags .= '<meta itemprop="name" content="' . $this->Tags['Title'] . '">' . "\n";
        $this->seoTags .= '<meta itemprop="description" content="' . $this->Tags['Content'] . '">' . "\n";
        $this->seoTags .= '<meta itemprop="url" content="' . $this->Tags['Link'] . '">' . "\n";

        $this->Tags = null;
    }

}
