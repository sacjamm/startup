<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminAcervo
 *
 * @author WEBLAB
 */
class AdminAcervo {

    private $Data;
    private $Post;
    private $Error;
    private $Result;

    const Entity = "acervo";

    public function ExeCreate(array $Data) {
        $this->Data = $Data;

        $this->setData();
        $this->setName();

        if ($this->Data['documentos']):
            $upload = new Upload;
            $upload->File($this->Data['documentos'], $this->Data['slug']);
        endif;

        if (isset($upload) && $upload->getResult()):
            $this->Data['documentos'] = $upload->getResult();
        $this->Data['slug'] = $this->Data['slug'];
            $this->Create();
        else:
            $this->Data['documentos'] = null;
        $this->Data['slug'] = $this->Data['slug'];
            $this->Create();
        endif;
    }

    public function ExeUpdate($PostId, array $Data) {
        $this->Post = (int) $PostId;
        $this->Data = $Data;
        
        $this->setData();
        $this->setName();

        if (is_array($this->Data['documentos'])):
            $readFile = new Read;
            $readFile->ExeRead(self::Entity, "where codigo = :cod", "cod={$this->Post}");
            $file = '../uploads/' . $readFile->getResult()[0]->documentos;

            if (file_exists($file) && !is_dir($file)):
                unlink($file);
            endif;

            $uploadFile = new Upload;
            $uploadFile->File($this->Data['documentos'], $this->Data['slug']);

        endif;
        
        if (isset($uploadFile) && $uploadFile->getResult()):
            $this->Data['documentos'] = $uploadFile->getResult();
        $this->Data['slug'] = $this->Data['slug'];
            $this->Update();
        else:
            $this->Data['slug'] = $this->Data['slug'];
            unset($this->Data['documentos']);
            $this->Update();
        endif;
        
        
    }
    
    public function ExeDelete($PostId) {
        $this->Post = (int) $PostId;

        $ReadPost = new Read;
        $ReadPost->ExeRead(self::Entity, "WHERE codigo = :codigo", "codigo={$this->Post}");

        if (!$ReadPost->getResult()):
            $this->Error = ["Os dados que você tentou deletar não existe no sistema!", WS_ERROR];
            $this->Result = false;
        else:
            $PostDelete = $ReadPost->getResult()[0];
            if (file_exists('uploads/' . $PostDelete->documentos) && !is_dir('uploads/' . $PostDelete->documentos)):
                unlink('uploads/' . $PostDelete->documentos);
            endif;

            

            $deleta = new Delete;
            $deleta->ExeDelete(self::Entity, "WHERE codigo = :cod", "cod={$this->Post}");

            $this->Error = ["Os dados foram removidos com sucesso do sistema!", WS_ACCEPT];
            $this->Result = true;

        endif;
    }

    public function getResult() {
        return $this->Result;
    }

    /**
     * <b>Obter Erro:</b> Retorna um array associativo com uma mensagem e o tipo de erro.
     * @return ARRAY $Error = Array associatico com o erro
     */
    public function getError() {
        return $this->Error;
    }

    private function setData() {
        $check = new Check();

        $Cover = $this->Data['documentos'];
        unset($this->Data['documentos']);

        $this->Data = array_map("strip_tags", $this->Data);
        $this->Data = array_map("trim", $this->Data);
        
        $this->Data['slug'] = $check->Name($this->Data['titulo']);

        $this->Data['data_de_indexacao'] = $check->Data($this->Data['data_de_indexacao']);
        $this->Data['documentos'] = $Cover;
    }
    
    //Verifica o NAME post. Se existir adiciona um pÃ³s-fix -Count
    private function setName() {
        $Where = (isset($this->Post) ? "codigo != {$this->Post} AND" : '');
        $readName = new Read;
        $readName->ExeRead(self::Entity, "WHERE {$Where} titulo = :t", "t={$this->Data['titulo']}");
        if ($readName->getResult()):
            $this->Data['slug'] = $this->Data['slug'] . '-' . $readName->getRowCount();
        endif;
    }

    private function Create() {
        $cadastra = new Create();
        $cadastra->ExeCreate(self::Entity, $this->Data);
        if ($cadastra->getResult()):
            $this->Error = ["Cadastro realizado com sucesso no sistema!", WS_ACCEPT];
            $this->Result = $cadastra->getResult();
        endif;
    }
    
    private function Update() {
        $Update = new Update();
        $Update->ExeUpdate(self::Entity, $this->Data, "where codigo = :cod", "cod={$this->Post}");
        if ($Update->getResult()):
            $this->Error = ["Dados atualizados com sucesso no sistema!", WS_ACCEPT];
            $this->Result = true;
        endif;
    }

}
