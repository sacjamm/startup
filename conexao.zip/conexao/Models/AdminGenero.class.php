<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminGenero
 *
 * @author WEBLAB
 */
class AdminGenero {

    private $Data;
    private $Post;
    private $Error;
    private $Result;

    const Entity = "acervo_genero";

    public function ExeCreate(array $Data) {
        $this->Data = $Data;

        $this->setData();
        $this->Create();
    }

    public function ExeUpdate($PostId, array $Data) {
        $this->Post = (int) $PostId;
        $this->Data = $Data;

        $this->setData();
        $this->Update();
    }

    public function ExeDelete($PostId) {
        $this->Post = (int) $PostId;

        $ReadPost = new Read;
        $ReadPost->ExeRead(self::Entity, "WHERE codigo = :codigo", "codigo={$this->Post}");

        if (!$ReadPost->getResult()):
            $this->Error = ["Os dados que você tentou deletar não existe no sistema!", WS_ERROR];
            $this->Result = false;
        else:
            $PostDelete = $ReadPost->getResult()[0];

            $deleta = new Delete;
            $deleta->ExeDelete(self::Entity, "WHERE codigo = :cod", "cod={$this->Post}");

            $this->Error = ["Os dados foram removidos com sucesso do sistema!", WS_ACCEPT];
            $this->Result = true;

        endif;
    }

    public function getResult() {
        return $this->Result;
    }

    /**
     * <b>Obter Erro:</b> Retorna um array associativo com uma mensagem e o tipo de erro.
     * @return ARRAY $Error = Array associatico com o erro
     */
    public function getError() {
        return $this->Error;
    }

    private function setData() {
        $check = new Check();


        $this->Data = array_map("strip_tags", $this->Data);
        $this->Data = array_map("trim", $this->Data);
    }


    private function Create() {
        $cadastra = new Create();
        $cadastra->ExeCreate(self::Entity, $this->Data);
        if ($cadastra->getResult()):
            $this->Error = ["Cadastro realizado com sucesso no sistema!", WS_ACCEPT];
            $this->Result = $cadastra->getResult();
        endif;
    }

    private function Update() {
        $Update = new Update();
        $Update->ExeUpdate(self::Entity, $this->Data, "where codigo = :cod", "cod={$this->Post}");
        if ($Update->getResult()):
            $this->Error = ["Dados atualizados com sucesso no sistema!", WS_ACCEPT];
            $this->Result = true;
        endif;
    }

}
