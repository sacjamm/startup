<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Curtidas
 *
 * @author WEBLAB
 */
class Curtidas {

    private $idCategoria;
    private $Ip;

    public function VerificarClicado($idCategoria, $Ip) {
        $read = new Read;
        $this->idCategoria = (int) $idCategoria;
        $this->Ip = $Ip;
        $read->ExeRead("ga_likes", "where ipVisitanteLike = :ipVisitante and idCategoria = :idCategoria", "ipVisitante={$this->Ip}&idCategoria={$this->idCategoria}");
        if ($read->getRowCount() >= 1):
            return true;
        else:
            return false;
        endif;
    }

    public function addClique($idCategoria, $Ip) {
        $this->idCategoria = (int) $idCategoria;
        $this->Ip = $Ip;
        $read = new Read;
        $update = new Update;
        
        $read->ExeRead("ga_categoria", "where idCategoria = :id", "id={$this->idCategoria}");
        if($read->getResult()):
            $extrair = $read->getResult()[0];
        endif;

        $ArrUpdate = ['LikeCategoria' => $extrair->LikeCategoria + 1];
        $update->ExeUpdate("ga_categoria", $ArrUpdate, "where idCategoria = :id", "id={$this->idCategoria}");

        if ($update->getResult()):
            $insert = new Create;

            $ArrInsert = ['idCategoria' => $this->idCategoria, 'ipVisitanteLike' => $this->Ip, 'StatusLike' => 1];
            $insert->ExeCreate("ga_likes", $ArrInsert);
            if ($insert->getResult()):
                return true;
            else:
                return false;
            endif;
        endif;
    }

    public function RetornaLikes($idCategoria) {
        $this->idCategoria = (int) $idCategoria;

        $read = new Read;
        $read->ExeRead("ga_categoria", "where idCategoria = :id", "id={$this->idCategoria}");
        if ($read->getResult()):
            return $read->getResult()[0];
        endif;
    }

}
