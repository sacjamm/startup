<?php

/**
 * AdminCategory.class [ MODEL ADMIN ]
 * Responável por gerenciar as categorias do sistema no admin!
 * 
 * @copyright (c) 2015, Alisson Maciel AGÊNCIA DIGITAL WEB LAB
 */
class AdminCategory {

    private $Data;
    private $CatId;
    private $CatSlug;
    private $Error;
    private $Result;

    //Nome da tabela no banco de dados!
    const Entity = "ga_categoria";

    /**
     * <b>Cadastrar Categoria:</b> Envelope titulo, descrição, data e sessão em um array atribuitivo e execute esse método
     * para cadastrar a categoria. Case seja uma sessão, envie o category_parent como STRING null.
     * @param ARRAY $Data = Atribuitivo
     */
    public function ExeCreate(array $Data) {
        $this->Data = $Data;
        $this->setData();

        if ($this->Data['ImagemCategoria']&&$this->Data['documentos']):
            $uplaod = new Upload;
            $uplaod->File($this->Data['ImagemCategoria'], $this->Data['SlugCategoria'], 'files', $this->Data['ImagemCategoria']['size']);
            $uplaod->File($this->Data['documentos'], "documentos-{$this->Data['SlugCategoria']}", 'documentos', $this->Data['documentos']['size']);
        endif;

        if (isset($uplaod) && $uplaod->getResult()):
            $this->Data['ImagemCategoria'] = $uplaod->getResult();
        $this->Data['documentos'] = $uplaod->getResult();
            $this->Create();
        else:
            $this->Data['ImagemCategoria'] = null;
        $this->Data['documentos'] = null;
            $this->Create();
        endif;
    }

    /**
     * <b>Atualizar Categoria:</b> Envelope os dados em uma array atribuitivo e informe o id de uma
     * categoria para atualiza-la!
     * @param INT $CategoryId = Id da categoria
     * @param ARRAY $Data = Atribuitivo
     */
    public function ExeUpdate($CategoryId, array $Data) {
        $this->CatId = (int) $CategoryId;
        $this->Data = $Data;
        $this->setData();

        if (is_array($this->Data['ImagemCategoria'])):
            $readCapa = new Read;
            $readCapa->ExeRead(self::Entity, "WHERE idCategoria = :post", "post={$this->CatId}");
            $capa = $_SERVER['DOCUMENT_ROOT'].'uploads/' . $readCapa->getResult()[0]->ImagemCategoria;
            if (file_exists($capa) && !is_dir($capa)):
                unlink($capa);
            endif;

            $uploadCapa = new Upload;
            $uploadCapa->File($this->Data['ImagemCategoria'], $this->Data['SlugCategoria'], 'files', $this->Data['ImagemCategoria']['size']);
        endif;

        if (isset($uploadCapa) && $uploadCapa->getResult()):
            $this->Data['ImagemCategoria'] = $uploadCapa->getResult();
            $this->Update();
        else:
            unset($this->Data['ImagemCategoria']);
            $this->Update();
        endif;
    }

    /**
     * <b>Deleta categoria:</b> Informe o ID de uma categoria para remove-la do sistema. Esse método verifica
     * o tipo de categoria e se é permitido excluir de acordo com os registros do sistema!
     * @param INT $CategoryId = Id da categoria
     */
    public function ExeDelete($CategoryId) {
        $this->CatId = (int) $CategoryId;

        $ReadPost = new Read;
        $ReadPost->ExeRead(self::Entity, "WHERE idCategoria = :post", "post={$this->CatId}");

        if (!$ReadPost->getResult()):
            $this->Error = ["A galeria que você tentou deletar não existe no sistema!", WS_ERROR];
            $this->Result = false;
        else:
            $PostDelete = $ReadPost->getResult()[0];
            if (file_exists($_SERVER['DOCUMENT_ROOT'].'uploads/' . $PostDelete->ImagemCategoria) && !is_dir($_SERVER['DOCUMENT_ROOT'].'uploads/' . $PostDelete->ImagemCategoria)):
                unlink($_SERVER['DOCUMENT_ROOT'].'uploads/' . $PostDelete->ImagemCategoria);
            endif;

            $deleta = new Delete;
            $deleta->ExeDelete(self::Entity, "WHERE idCategoria = :postid", "postid={$this->CatId}");

            $this->Error = ["A Anunciante <b>{$PostDelete->Categoria}</b> foi removida com sucesso do sistema!", WS_ACCEPT];
            $this->Result = true;

        endif;
    }

    /**
     * <b>Verificar Cadastro:</b> Retorna TRUE se o cadastro ou update for efetuado ou FALSE se não. Para verificar
     * erros execute um getError();
     * @return BOOL $Var = True or False
     */
    public function getResult() {
        return $this->Result;
    }

    /**
     * <b>Obter Erro:</b> Retorna um array associativo com a mensagem e o tipo de erro!
     * @return ARRAY $Error = Array associatico com o erro
     */
    public function getError() {
        return $this->Error;
    }

    /*
     * ***************************************
     * **********  PRIVATE METHODS  **********
     * ***************************************
     */

    //Valida e cria os dados para realizar o cadastro
    private function setData() {
        $Cover = $this->Data['ImagemCategoria'];
        unset($this->Data['ImagemCategoria']);
        $this->Data['ImagemCategoria'] = $Cover;
        
        $Covers = $this->Data['documentos'];
        unset($this->Data['documentos']);
        $this->Data['documentos'] = $Covers;

        $check = new Check;
        $this->Data['SlugCategoria'] = $check->Name($this->Data['Email']);
        $this->Data['StatusCategoria'] = 1;
    }

    //Verifica o NAME da categoria. Se existir adiciona um pós-fix +1
    private function setName() {
        $Where = (!empty($this->CatId) ? "idCategoria != {$this->CatId} AND" : '' );

        $readName = new Read;
        $readName->ExeRead(self::Entity, "WHERE {$Where} Categoria = :t", "t={$this->Data['Categoria']}");
        if ($readName->getResult()):
            $this->Data['SlugCategoria'] = $this->Data['SlugCategoria'] . '-' . $readName->getRowCount();
        endif;
    }

    //Cadastra a categoria no banco!
    private function Create() {
        $Create = new Create;
        $Create->ExeCreate(self::Entity, $this->Data);
        if ($Create->getResult()):
            $this->Result = $Create->getResult();
            $this->Error = ["<b>Sucesso:</b> Cadastro efetuado com sucesso no sistema! Aguarde redirecionamento...", WS_ACCEPT];
        endif;
    }

    //Atualiza Categoria
    private function Update() {
        $Update = new Update;
        $Update->ExeUpdate(self::Entity, $this->Data, "WHERE idCategoria = :catid", "catid={$this->CatId}");
        if ($Update->getResult()):
            $this->Result = true;
            $this->Error = ["<b>Sucesso:</b> Cadastro atualizado com sucesso no sistema!", WS_ACCEPT];
        endif;
    }

    public function gbSend(array $Images, $CategoryId) {
        $this->CatId = (int) $CategoryId;
        $this->Data = $Images;

        $ImageName = new Read;
        $ImageName->ExeRead(self::Entity, "where idCategoria = :id", "id={$this->CatId}");

        if (!$ImageName->getResult()):
            $this->Error = ["Erro ao enviar galeria. O índice {$this->CatId} não foi encontrado no banco de daods.", WS_ERROR];
            $this->Result = false;
        else:
            $ImageName = $ImageName->getResult()[0]->SlugCategoria;

            $gbFiles = array();
            $gbCount = count($this->Data['tmp_name']);
            $gbKeys = array_keys($this->Data);

            for ($gb = 0; $gb < $gbCount; $gb++):
                foreach ($gbKeys as $keys):
                    $gbFiles[$gb][$keys] = $this->Data[$keys][$gb];
                endforeach;
            endfor;
            $gbSend = new Upload;
            $i = 0;
            $u = 0;

            foreach ($gbFiles as $gbUpload):
                $i++;
                $ImgName = "{$ImageName}-gb-{$this->CatId}-" . (substr(md5(time() + $i), 0, 5));
                $gbSend->File($gbUpload, $ImgName);

                if ($gbSend->getResult()):
                    $gbImage = $gbSend->getResult();
                    $gbCreate = ['idCategoria' => $this->CatId, 'ImagemGaleria' => $gbImage, 'DataGaleria' => date('Y-m-d H:i:s')];
                    $insetGb = new Create;
                    $insetGb->ExeCreate("ga_galeria", $gbCreate);
                    $u++;
                endif;

            endforeach;

            if ($u > 1):
                $this->Error = ["Galeria Atualizada: Foram enviadas {$u} imagens para esta galeria!", WS_ACCEPT];
                $this->Result = true;
            endif;


        endif;
    }

    /**
     * <b>Deletar Imagem da galeria:</b> Informe apenas o id da imagem na galeria para que esse mÃ©todo leia e remova
     * a imagem da pasta e delete o registro do banco!
     * @param INT $GbImageId = Id da imagem da galleria
     */
    public function gbRemove($GbImageId) {
        $this->CatId = (int) $GbImageId;
        $readGb = new Read;
        $readGb->ExeRead("ga_galeria", "WHERE idGaleria = :gb", "gb={$this->CatId}");
        if ($readGb->getResult()):

            $Imagem = $_SERVER['DOCUMENT_ROOT'].'uploads/' . $readGb->getResult()[0]->ImagemGaleria;

            if (file_exists($Imagem) && !is_dir($Imagem)):
                unlink($Imagem);
            endif;

            $Deleta = new Delete;
            $Deleta->ExeDelete("ga_galeria", "WHERE idGaleria = :id", "id={$this->CatId}");
            if ($Deleta->getResult()):
                $this->Error = ["A imagem foi removida com sucesso da galeria!", WS_ACCEPT];
                $this->Result = true;
            endif;

        endif;
    }

}
