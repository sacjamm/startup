<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Galeria
 *
 * @author WEBLAB
 */
class Galeria {

    private $Galeria;
    private $Error;
    private $PostId;
    private $Result;
    
    const Entity = 'loja_produtos';

    public function gbSend(array $Images, $PostId) {
        $this->Galeria = $Images;
        //$this->PostId = $PostId;
        
//        $ImageName = new Read;
//        $ImageName->ExeRead(self::Entity, "WHERE post_id = :id", "id={$this->PostId}");
//
//        if (!$ImageName->getResult()):
//            $this->Error = ["Erro ao enviar galeria. O índice {$this->PostId} não foi encontrado no banco!", WS_ERROR];
//            $this->Result = false;
//        else:
//        $ImageName = $ImageName->getResult()[0]['post_name'];

        $gbFiles = array();
        $gbCount = count($this->Galeria['tmp_name']);
        $gbKeys = array_keys($this->Galeria);

        for ($gb = 0; $gb < $gbCount; $gb++):
            foreach ($gbKeys as $Keys):
                $gbFiles[$gb][$Keys] = $this->Galeria[$Keys][$gb];
            endforeach;
        endfor;

        $gbSend = new Upload();
        $i = 0;
        $u = 0;

        foreach ($gbFiles as $gbUpload):
            $i++;
            $data = date('d-m-Y');
            
            $ImgName = "{$ImageName}-{$this->PostId}-{$data}-{$gbUpload['name']}";
            $gbSend->Image($gbUpload, $ImgName, null, "bibliotecas/");
            
            if($gbSend->getResult()):
                
            endif;
            
            echo '<pre>';
            //var_dump($gbFiles);
            echo '</pre>';
        endforeach;
    }

    function getError() {
        return $this->Error;
    }

    function getResult() {
        return $this->Result;
    }

}
